import { useEffect, useRef, useState } from "react";
import {
  Menu, X, ArrowRight, ArrowUpRight, Phone, Mail, MapPin, Building2, HardHat,
  Ruler, Hammer, PaintRoller, ShieldCheck, Check,
} from "lucide-react";

const img = (id, w = 1400) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=80`;
const IMG = {
  hero: "photo-1541888946425-d81bb19240f5",
  about: "photo-1504307651254-35680f356dfd",
  p1: "photo-1486406146926-c627a92ad1ab",
  p2: "photo-1487958449943-2429e8be8625",
  p3: "photo-1503387762-592deb58ef4e",
  p4: "photo-1541888946425-d81bb19240f5",
  p5: "photo-1504307651254-35680f356dfd",
  p6: "photo-1486406146926-c627a92ad1ab",
};

const NAV = ["Home", "About", "Services", "Projects", "Contact"];

const SERVICES = [
  { icon: Building2, title: "Commercial Construction", text: "Offices, retail and mixed-use developments delivered on schedule and on budget." },
  { icon: HardHat, title: "Residential Building", text: "Bespoke villas and apartment complexes crafted with architectural precision." },
  { icon: Ruler, title: "Design & Planning", text: "Concept to permit-ready drawings by our in-house architects and engineers." },
  { icon: Hammer, title: "Renovation & Restoration", text: "Breathing new life into existing structures while respecting their character." },
  { icon: PaintRoller, title: "Interior Fit-Out", text: "Premium finishes, joinery and detailing for spaces that feel considered." },
  { icon: ShieldCheck, title: "Project Management", text: "Transparent reporting, strict safety standards and one accountable team." },
];

const PROJECTS = [
  { img: IMG.p1, title: "Meridian Tower", tag: "Commercial", year: "2025" },
  { img: IMG.p2, title: "Aurora Residences", tag: "Residential", year: "2024" },
  { img: IMG.p3, title: "Harbor Studio", tag: "Design", year: "2024" },
  { img: IMG.p4, title: "Northgate Logistics Hub", tag: "Industrial", year: "2023" },
  { img: IMG.p5, title: "Oakline Villas", tag: "Residential", year: "2023" },
  { img: IMG.p6, title: "Civic Plaza Office", tag: "Commercial", year: "2022" },
];

const STATS = [["15+", "Years of experience"], ["220", "Projects delivered"], ["98%", "Client satisfaction"], ["40", "Expert engineers"]];

function Reveal({ children, delay = 0, className = "" }) {
  const ref = useRef(null);
  const [show, setShow] = useState(false);
  useEffect(() => {
    const io = new IntersectionObserver(([e]) => e.isIntersecting && (setShow(true), io.disconnect()), { threshold: 0.15 });
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} style={{ transitionDelay: `${delay}ms` }}
      className={`transition-all duration-1000 ease-out ${show ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"} ${className}`}>
      {children}
    </div>
  );
}

function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 40);
    on();
    window.addEventListener("scroll", on);
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled || open ? "bg-ink/85 py-3 backdrop-blur-xl border-b border-white/10" : "py-6"}`}>
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6">
        <a href="#home" className="flex items-center gap-2 font-display text-2xl font-semibold">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-gold text-ink"><Building2 size={20} /></span>
          Build<span className="text-gold">Core</span>
        </a>
        <ul className="hidden items-center gap-10 md:flex">
          {NAV.map((n) => (
            <li key={n}>
              <a href={`#${n.toLowerCase()}`} className="group relative text-sm font-medium text-white/80 transition hover:text-white">
                {n}
                <span className="absolute -bottom-1.5 left-0 h-px w-0 bg-gold transition-all duration-300 group-hover:w-full" />
              </a>
            </li>
          ))}
        </ul>
        <a href="#contact" className="btn-gold hidden !py-2.5 md:inline-flex">Get a Quote</a>
        <button aria-label="Menu" onClick={() => setOpen(!open)} className="md:hidden">{open ? <X /> : <Menu />}</button>
      </nav>
      <div className={`overflow-hidden transition-all duration-500 md:hidden ${open ? "max-h-96" : "max-h-0"}`}>
        <ul className="space-y-1 px-6 pb-6 pt-4">
          {NAV.map((n) => (
            <li key={n}><a onClick={() => setOpen(false)} href={`#${n.toLowerCase()}`} className="block border-b border-white/10 py-3 text-lg">{n}</a></li>
          ))}
        </ul>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="home" className="relative flex min-h-screen items-center overflow-hidden">
      <img src={img(IMG.hero, 2000)} alt="" className="absolute inset-0 h-full w-full animate-zoom object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-ink/30" />
      <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" />
      <div className="relative mx-auto w-full max-w-7xl px-6 pb-32 pt-40">
        <p className="eyebrow animate-fadeUp">Construction · Architecture · Renovation</p>
        <h1 className="max-w-3xl animate-fadeUp font-display text-5xl font-semibold leading-[1.05] [animation-delay:.15s] sm:text-6xl lg:text-7xl">
          We build the <span className="italic text-gold">landmarks</span> of tomorrow.
        </h1>
        <p className="mt-6 max-w-xl animate-fadeUp text-lg font-light text-white/70 [animation-delay:.3s]">
          Precision engineering, refined design and uncompromising craftsmanship, from the first sketch to the final handover.
        </p>
        <div className="mt-10 flex animate-fadeUp flex-wrap gap-4 [animation-delay:.45s]">
          <a href="#projects" className="btn-gold">View Our Work <ArrowRight size={16} /></a>
          <a href="#contact" className="btn-ghost">Start a Project</a>
        </div>
      </div>
      <div className="absolute inset-x-0 bottom-0 border-t border-white/10 bg-ink/60 backdrop-blur-md">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-6 py-6 md:grid-cols-4">
          {STATS.map(([n, l]) => (
            <div key={l}><div className="font-display text-3xl text-gold">{n}</div><div className="text-xs uppercase tracking-widest text-white/50">{l}</div></div>
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  const points = ["Licensed, insured and certified teams", "Fixed-price contracts with zero surprises", "Sustainable materials and methods"];
  return (
    <section id="about" className="mx-auto grid max-w-7xl items-center gap-16 px-6 py-28 lg:grid-cols-2 lg:py-36">
      <Reveal className="relative">
        <div className="overflow-hidden rounded-3xl">
          <img src={img(IMG.about, 1000)} alt="Construction team on site" className="aspect-[4/5] w-full object-cover transition duration-700 hover:scale-105" />
        </div>
        <div className="absolute -bottom-8 -right-4 rounded-2xl bg-gold p-7 text-ink shadow-2xl md:-right-8">
          <div className="font-display text-5xl font-semibold">15+</div>
          <div className="text-sm font-medium">Years of building<br />excellence</div>
        </div>
      </Reveal>
      <Reveal delay={150}>
        <p className="eyebrow">About Us</p>
        <h2 className="h2">Craftsmanship you can see. Reliability you can trust.</h2>
        <p className="mt-6 leading-relaxed text-white/65">
          BuildCore is a full-service construction company combining modern engineering with the care of a family-run studio. We partner with owners, developers and architects to deliver buildings that are beautiful, durable and built to the schedule we promise.
        </p>
        <ul className="mt-8 space-y-4">
          {points.map((p) => (
            <li key={p} className="flex items-center gap-3 text-white/85">
              <span className="grid h-6 w-6 place-items-center rounded-full bg-gold/15 text-gold"><Check size={14} /></span>{p}
            </li>
          ))}
        </ul>
        <a href="#contact" className="btn-gold mt-10">Talk to our team <ArrowRight size={16} /></a>
      </Reveal>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="bg-steel py-28 lg:py-36">
      <div className="mx-auto max-w-7xl px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">Our Services</p>
          <h2 className="h2">Everything you need, under one roof.</h2>
        </Reveal>
        <div className="mt-16 grid gap-px overflow-hidden rounded-3xl border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map(({ icon: Icon, title, text }, i) => (
            <Reveal key={title} delay={i * 80} className="group relative bg-steel p-10 transition duration-500 hover:bg-ink">
              <div className="mb-8 grid h-14 w-14 place-items-center rounded-2xl border border-gold/30 text-gold transition duration-500 group-hover:bg-gold group-hover:text-ink"><Icon size={26} /></div>
              <h3 className="font-display text-2xl">{title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-white/55">{text}</p>
              <ArrowUpRight className="absolute right-8 top-8 text-white/20 transition duration-500 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-gold" />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Projects() {
  return (
    <section id="projects" className="mx-auto max-w-7xl px-6 py-28 lg:py-36">
      <Reveal className="flex flex-wrap items-end justify-between gap-6">
        <div><p className="eyebrow">Our Projects</p><h2 className="h2 max-w-xl">Selected work that speaks for itself.</h2></div>
        <a href="#contact" className="btn-ghost">Discuss your project</a>
      </Reveal>
      <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {PROJECTS.map((p, i) => (
          <Reveal key={p.title} delay={(i % 3) * 100}>
            <article className={`group relative overflow-hidden rounded-3xl bg-steel ${i % 4 === 0 ? "aspect-[4/5]" : "aspect-[4/4.4]"}`}>
              <img src={img(p.img, 900)} alt={p.title} loading="lazy" className="h-full w-full object-cover transition duration-[1200ms] group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/10 to-transparent opacity-80 transition group-hover:opacity-100" />
              <span className="absolute left-5 top-5 rounded-full bg-ink/60 px-3 py-1 text-xs backdrop-blur">{p.tag}</span>
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-6 transition duration-500 group-hover:-translate-y-1">
                <div><h3 className="font-display text-2xl">{p.title}</h3><p className="text-sm text-white/60">{p.year}</p></div>
                <span className="grid h-11 w-11 place-items-center rounded-full bg-gold text-ink opacity-0 transition duration-500 group-hover:opacity-100"><ArrowUpRight size={18} /></span>
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function Contact() {
  const [sent, setSent] = useState(false);
  const submit = (e) => { e.preventDefault(); setSent(true); e.target.reset(); setTimeout(() => setSent(false), 5000); };
  const field = "w-full rounded-xl border border-white/10 bg-white/5 px-5 py-4 text-sm outline-none transition placeholder:text-white/35 focus:border-gold focus:bg-white/10";
  const info = [[Phone, "+1 (555) 123-4567"], [Mail, "hello@buildcore.com"], [MapPin, "24 Foundry Street, Your City"]];
  return (
    <section id="contact" className="bg-steel py-28 lg:py-36">
      <div className="mx-auto grid max-w-7xl gap-16 px-6 lg:grid-cols-5">
        <Reveal className="lg:col-span-2">
          <p className="eyebrow">Contact</p>
          <h2 className="h2">Let’s build something extraordinary.</h2>
          <p className="mt-6 text-white/60">Tell us about your project and we’ll reply within one business day with next steps.</p>
          <ul className="mt-10 space-y-6">
            {info.map(([Icon, t]) => (
              <li key={t} className="flex items-center gap-4">
                <span className="grid h-12 w-12 place-items-center rounded-full border border-gold/30 text-gold"><Icon size={18} /></span>{t}
              </li>
            ))}
          </ul>
        </Reveal>
        <Reveal delay={150} className="lg:col-span-3">
          <form onSubmit={submit} className="space-y-5 rounded-3xl border border-white/10 bg-ink p-8 md:p-10">
            <div className="grid gap-5 sm:grid-cols-2">
              <input required name="name" placeholder="Full name" className={field} />
              <input required type="email" name="email" placeholder="Email address" className={field} />
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              <input name="phone" placeholder="Phone (optional)" className={field} />
              <select name="type" defaultValue="" className={`${field} appearance-none`}>
                <option value="" disabled>Project type</option>
                <option className="text-ink">Commercial</option><option className="text-ink">Residential</option>
                <option className="text-ink">Renovation</option><option className="text-ink">Other</option>
              </select>
            </div>
            <textarea required name="message" rows="5" placeholder="Tell us about your project..." className={field} />
            <button className="btn-gold w-full justify-center">Send Message <ArrowRight size={16} /></button>
            <p className={`text-center text-sm text-gold transition-all duration-500 ${sent ? "opacity-100" : "h-0 opacity-0"}`}>Thank you! We’ll be in touch shortly.</p>
          </form>
        </Reveal>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-white/10 py-10 text-center text-sm text-white/40">
      © {new Date().getFullYear()} BuildCore Construction. All rights reserved.
    </footer>
  );
}

export default function App() {
  return (<><Navbar /><main><Hero /><About /><Services /><Projects /><Contact /></main><Footer /></>);
}
